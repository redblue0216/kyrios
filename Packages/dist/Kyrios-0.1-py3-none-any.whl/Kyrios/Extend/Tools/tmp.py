class test_source_target(object):
    
    def test():
        print("test!")


def set_age(self,age):
    self.data['age'] = age
    return 'set age successful!'
    
def set_sex(self,sex):
    self.data['sex'] = sex
    return 'set sex successful!'

def set_value(self,value):
    self.data['value'] = value 
    return 'set value successful!'

def set_test(self,test):
    self.data['test'] = test
    return 'set test successful!'
