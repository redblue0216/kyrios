# import sys,os
# BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
# print(os.path.abspath(__file__))
# print(os.path.dirname(os.path.abspath(__file__)))
# print(BASE)
# sys.path.insert(0, BASE)
# print("测试Hello")